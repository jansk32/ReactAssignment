import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route,IndexRoute, useParams } from 'react-router-dom'
import {App, Movie, addMovie} from './App.js';




ReactDOM.render(
    <Router>
     <Route exact path="/" component={App} >
         </Route>
    <Route exact path="/MovieID/:id" component={Movie}>
        </Route>
    <Route exact path="/addMovie" component={addMovie}>
    </Route>
      </Router>, document.getElementById('app'))