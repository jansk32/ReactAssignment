import React, {Component}from 'react';

var movies = 
{ "data": [
   { "movieId": "1",
       "movieName": "Empire Strikes Back",
       "leadActor": "Mark Hamil",
       "leadActress": "Carrie Fisher",
       "yearOfRelease": " 1980",
       "language": "English",
       "collections": "Star Wars"
   }
],
"currId": "1"
}


class App extends Component{
   render(){
      return(
         <div>
            <h1>Movie Details Management</h1>
            <Home data = {movies}/>
         </div>
      );
   }
}

class Home extends Component{
   
   render(){
      let movies = this.props.data
      return(
         <div>
            {movies.data.map((m) => {
               return(
                  <div>
                     <h1>{m.movieName}</h1>
                     <h3>Movie ID: {m.movieId}</h3>
                     <h3>Lead Actor: {m.leadActor}</h3>
                     <h3>Lead Actree: {m.leadActress}</h3>
                     <h3>Year of Release: {m.yearOfRelease}</h3>
                     <h3>Language: {m.language}</h3>
                     <h3>Collections: {m.collections}</h3>
                     <br />
                  </div>
               )
            })}
         </div>
      )
   }
}

class Movie extends Component{
   constructor() {
      super()
      this.findMovie = this.findMovie.bind(this)
   }
   

   findMovie(id){
      for (let i=0; i< movies.data.length; i++){
         if (movies.data[i].movieId === id) {
            return movies.data[i]
         }
      }
   }


   render(){
      let id = this.props.match.params.id
      let m = this.findMovie(id)
      return(
         <div>
            <h1>MOVIE ID</h1>
            <h3>Movie ID: {m.movieId}</h3>
            <h3>Movie Name: {m.movieName}</h3>
            <h3>Lead Actor: {m.leadActor}</h3>
            <h3>Lead Actree: {m.leadActress}</h3>
            <h3>Year of Release: {m.yearOfRelease}</h3>
            <h3>Language: {m.language}</h3>
            <h3>Collections: {m.collections}</h3>
         </div>
      )
   }
}

class addMovie extends Component{
   constructor(){
      super()
      this.add = this.add.bind(this)
      this.delete = this.delete.bind(this)
      this.state = movies
   }

   add(e){
      e.preventDefault()
      let newId = parseInt(this.state.currId) + 1
      let newData = {
         movieId: newId,
         movieName: e.target.movieName.value,
         leadActor: e.target.leadActor.value,
         leadActress: e.target.leadActress.value,
         yearOfRelease: e.target.yearOfRelease.value,
         language: e.target.language.value,
         collections: e.target.collection.value
      }

      
      movies.data.push(newData)
     
      
      this.setState({data : movies.data, currId: newId})
   }


   delete(e){
      e.preventDefault()
      let delId = parseInt(e.target.del.value)
      for (let i = 0; i< this.state.data.length; i++){
         if (parseInt(this.state.data[i].movieId) === delId){
            this.state.data.splice(i, 1)
            this.setState({data: this.state.data, currId: this.state.data.currId})
         }
      }
   }



   render(){
      return(
         <div>
            <h1>Add a movie!</h1>
            <form onSubmit={this.add}>
               <input type="text" placeholder="Movie Title" name= "movieName"></input>
               <input type="text" placeholder="Lead Actor" name="leadActor"></input>
               <input type="text" placeholder="Lead Actree" name= "leadActress"></input>
               <input type="text" placeholder="Year of Release" name= "yearOfRelease"></input>
               <input type="text" placeholder="Language" name= "language"></input>
               <input type="text" placeholder="Collection" name= "collection"></input>
               <button>Submit</button>
            </form>
            <form onSubmit={this.delete}>
            <label>Delete a Movie: 
               <input type="number" placeholder="MovieId" name="del"></input>
               <button>Submit</button>
               </label>
            </form>
            <h1>Movies List: </h1>
            <br />
            <Home data = {this.state}/>
      </div>
      )
   }
}


export {
   App, Movie, addMovie
};
