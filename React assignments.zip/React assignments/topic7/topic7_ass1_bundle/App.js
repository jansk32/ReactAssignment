import React, { Component } from 'react';
import PropTypes from 'prop-types'

class App extends Component{
   render(){
      return(
         <div>
            <h1>{this.props.name}</h1>
            <h1>{this.props.preferredCities}</h1>
            <h2>{(this.props.age >= 18 && this.props.age <= 60) ? this.props.age : false}</h2>
         </div>
      );
   }
}

App.propTypes ={
   name: PropTypes.string.isRequired,
   preferredCities: PropTypes.arrayOf(PropTypes.string),
   age: PropTypes.number
}

App.defaultProps = {
   name: "Steve",
   preferredCities: ["Bangalore", "Chennai"],
   age: 18
}

export default App;