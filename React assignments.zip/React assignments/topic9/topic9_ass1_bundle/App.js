import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class App extends Component{
   constructor(){
      super()
   }


   render(){
      return(
         <div>
            <Div />
            <h1>What a lovely day!</h1>
         </div>
      );
   }
}

class Div extends Component{
   constructor(){
      super()
      this.removeDiv = this.removeDiv.bind(this)
   }
   componentWillMount() {
      console.log("Component will be mounted")
   }

   componentDidMount() {
      console.log("Component Did Mount")
   }
   componentWillReceiveProps(newProps) {    
      console.log('Component WILL RECIEVE PROPS!')
   }
   shouldComponentUpdate(newProps, newState) {
      return true;
   }
   componentWillUpdate(nextProps, nextState) {
      console.log('Component WILL UPDATE!');
   }
   componentDidUpdate(prevProps, prevState) {
      console.log('Component DID UPDATE!')
   }

   componentWillUnmount(){
      console.log("Component UNMOUNTED")
   }
   
   removeDiv(){
         console.log("Here")
         ReactDOM.unmountComponentAtNode(document.getElementById("app"))
         this.setState({status: "Component Unmounted"})
   }

   render(){
      return(
         <button id="button" onClick={this.removeDiv}>DIV</button>
      )
   }
}

export default App;
