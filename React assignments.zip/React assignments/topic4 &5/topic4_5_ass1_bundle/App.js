import React, { Component } from 'react';

class App extends Component{
    render(){
       return(
          <div>
             <Main />
          </div>
       );
    }
 }
 
class Main extends Component{
    constructor(){
       super()
       this.state= {
       student: [
       {studentId: 1,
          studentName: "Penny",
          studentMark: 78},
 
       {studentId: 2,
          studentName: "Peter",
          studentMark: 90},
 
       {studentId: 3,
          studentName: "Jake",
          studentMark: 43},
 
       {studentId: 4,
          studentName: "Taiko",
          studentMark: 100},
 
       {studentId: 5,
          studentName: "Angela",
          studentMark: 100}
       ]
    }
    }
 
    render(){
       return(
       <div>
          <Header/>
          <Details data={this.state.student}/>
       </div>
       )
    }
 }
 
 class Header extends Component{
    render() {
       return(
          <h1>Student Details</h1>
       )
    }
 }
 
 class Details extends Component{
 
    render(){
       return(
          <table border={1}>
          <tbody>
             <tr>
                <th>Id</th>
                <th>Student Name</th>
                <th>Mark</th>
             </tr>
             {this.props.data.map((student) => {
                return(<tr>
                   <td>{student.studentId}</td>
                   <td>{student.studentName}</td>
                <td>{student.studentMark}</td>
                </tr>)
             })}
          </tbody>
       </table>
       )
    }
 }
 
 export default App;
 
 
 