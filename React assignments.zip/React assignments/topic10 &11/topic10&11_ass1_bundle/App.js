import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class App extends Component{
   constructor(){
      super()
      this.state = {
         total: 0
      }
      this.updateTotal = this.updateTotal.bind(this)
   }

   updateTotal(){
      let phy = document.getElementById('phy').value || 0
      let bio = document.getElementById('bio').value || 0
      let chem = document.getElementById('chem').value || 0
      let math = document.getElementById('math').value || 0
      let newTotal = this.state.total + parseInt(phy) + parseInt(bio) + parseInt(chem) + parseInt(math)
      this.setState({total: newTotal})
   }

   render(){
      return(
         <div>
            <Form physics= {this.state.physics} updateProp = {this.updateTotal}/>
         <button onClick={this.updateTotal}>TAKE AVERAGE</button>
         <h1>Average: {this.state.total /4}</h1>
         </div>
      );
   }
}

class Form extends Component{
   render(){
      return(
         <div>
         <form>
            <h3>Physics:   <input id="phy" type="number"></input></h3>
            <h3>Biology:   <input id="bio" type="number" ></input></h3>
            <h3>Chemistry:   <input id="chem" type="number"></input></h3>
            <h3>Mathematics:   <input id="math" type="number"></input></h3>
         </form>
         </div>
      )
   }
}


export default App;