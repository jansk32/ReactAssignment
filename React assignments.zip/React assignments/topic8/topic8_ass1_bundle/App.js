import React, { Component } from 'react';

class App extends Component{
   constructor(){
      super()
      this.state = {currNum: 0,
      rows: []}
      this.displayTable = this.displayTable.bind(this)
   }

   displayTable(){
      let newArr = this.state.rows.slice()
      newArr.push((
         <tr>
            <td>{this.state.currNum}</td>
            <td>X</td>
            <td>5</td>
            <td>=</td>
            <td>{this.state.currNum * 5}</td>
         </tr>
      )
      )
      this.setState({rows: newArr})
      this.setState({currNum: (this.state.currNum + 1)})
   }

   render(){
      return(
         <div>
            <h1>Topic 8 Assessment</h1>
            <button onClick={this.displayTable}>Click to generate Multiplication tables of 5</button>
            <table>
               <tbody>
                  {this.state.rows.map((elem) => elem)}
               </tbody>
            </table>
         </div>
      );
   }
}


export default App;
