import React, { Component } from 'react';

class App extends Component{
   render(){
      return(
         <div>
            <h1>Happy Learning-React</h1>
            <table>
               <tr>
                  <th>Employee Name</th>
                  <th>Employee ID</th>
                  <th>Employee Email</th>
               </tr>
               <tr>
                  <td>James</td>
                  <td>1234</td>
                  <td>ja1234@wipro.com</td>
               </tr>
               <tr>
                  <td>Karol</td>
                  <td>5678</td>
                  <td>ka5678@wipro.com</td>
               </tr>
               <tr>
                  <td>Lad</td>
                  <td>1837</td>
                  <td>la1837@wipro.com</td>
               </tr>
               <tr>
                  <td>Jess</td>
                  <td>7189</td>
                  <td>je7189@wipro.com</td>
               </tr>
               <tr>
                  <td>Lobo</td>
                  <td>0162</td>
                  <td>lo0162@wipro.com</td>
               </tr>
            </table>
         </div>
      );
   }
}
export default App;