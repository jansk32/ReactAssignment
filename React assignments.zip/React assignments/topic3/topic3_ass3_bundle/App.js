import React, { Component } from 'react';

class App extends Component{
   render(){
      return(
         <div>
            <h1>Happy Learning-React</h1>
            <table>
               {[1,2,3,4,5,6,7,8,9,10].map((val) => {
                return (<tr>
                   <td>{val}</td>
                   <td>X</td>
                   <td>5</td>
                   <td>=</td>
                   <td>{val*5}</td>
                  </tr>)  
               })}
            </table>
         </div>
      );
   }
}
export default App;